<?php
defined('ABSPATH')||exit;
final class SVW_Helpers{
	const TYPE='svw_video';const TAX='svw_category';
	public static function categories(){return array('founder-update'=>'Founder Update','classical-homeopathy'=>'Classical Homeopathy','homeopathy-education'=>'Homeopathy Education','materia-medica'=>'Materia Medica','repertory'=>'Repertory','clinical-education'=>'Clinical Education','patient-cases'=>'Patient Cases','homeopathy-philosophy'=>'Homeopathy Philosophy','research'=>'Research','nutrition'=>'Nutrition','public-health-education'=>'Public Health Education','pathology'=>'Pathology','anatomy'=>'Anatomy','principles-hygiene'=>'Principles of Hygiene','islamic-spiritual-healing'=>'Islamic Spiritual Healing','platform-news'=>'Platform News');}
	public static function founder($id=0){$id=$id?:get_current_user_id();return $id&&$id===absint(get_option('spf_founder_user_id',0));}
	public static function doctor($id=0){$id=$id?:get_current_user_id();return $id&&class_exists('SPD_Helpers')&&SPD_Helpers::is_doctor($id)&&'verified'===SPD_Helpers::verification_status($id);}
	public static function can_submit($id=0){$id=$id?:get_current_user_id();return $id&&(user_can($id,'manage_video_wall')||self::founder($id)||self::doctor($id));}
	public static function initial_status($id=0){$id=$id?:get_current_user_id();return user_can($id,'manage_video_wall')||self::founder($id)?'publish':'pending';}
	public static function meta($id,$key,$default=''){$v=get_post_meta(absint($id),'_svw_'.$key,true);return ''===$v?$default:$v;}
	public static function category($id){$t=get_the_terms($id,self::TAX);return $t&&!is_wp_error($t)?$t[0]->name:'';}
	public static function duration($seconds){$seconds=absint($seconds);return $seconds?sprintf('%02d:%02d:%02d',floor($seconds/3600),floor(($seconds%3600)/60),$seconds%60):'';}
	public static function parse_duration($value){$p=array_reverse(array_map('absint',explode(':',$value)));return(isset($p[0])?$p[0]:0)+(isset($p[1])?$p[1]*60:0)+(isset($p[2])?$p[2]*3600:0);}
	public static function embed($id){$source=self::meta($id,'source');$url=self::meta($id,'video_url');if('youtube'===$source&&preg_match('~(?:youtu\.be/|youtube\.com/(?:watch\?v=|embed/))([A-Za-z0-9_-]{6,20})~',$url,$m)){return '<iframe src="https://www.youtube-nocookie.com/embed/'.esc_attr($m[1]).'" title="'.esc_attr(get_the_title($id)).'" loading="lazy" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>';}if('vimeo'===$source&&preg_match('~vimeo\.com/(?:video/)?([0-9]+)~',$url,$m)){return '<iframe src="https://player.vimeo.com/video/'.esc_attr($m[1]).'" title="'.esc_attr(get_the_title($id)).'" loading="lazy" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>';}if('local'===$source){$attachment=absint(self::meta($id,'attachment_id'));$src=$attachment?wp_get_attachment_url($attachment):'';return $src?wp_video_shortcode(array('src'=>$src,'preload'=>'metadata')):'';}return '';}
	public static function nav(){return class_exists('SDD_Helpers')?str_replace('class="sdd-main-nav"','class="svw-main-nav"',SDD_Helpers::navigation()):'';}
}

