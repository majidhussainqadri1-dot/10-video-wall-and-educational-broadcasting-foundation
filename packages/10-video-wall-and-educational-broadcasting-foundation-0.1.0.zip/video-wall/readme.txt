=== Video Wall and Educational Broadcasting Foundation ===
Contributors: sabrihomeopathy
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later

The first 25 percent of an American English educational Video Wall.

== Features ==
Public viewing, sixteen fixed categories, Founder immediate publishing, verified-doctor moderation, safe YouTube/Vimeo embeds, validated local video, search, filters, trending, views, Like, Dislike, saves, reports, comments, transcripts, references, patient-case safeguards, moderation, privacy callbacks, responsive design, and VideoObject structured data.

== Installation ==
Keep Files 02, 03, 04, 07, and 09 active. Upload and activate this ZIP. Open Video Wall Management, test each source type, and publish a test video before public launch.

== Limitations ==
Live streaming, payments, advertising, automatic captions, AI summaries, playlists, fingerprinting, and Reels are not included.

